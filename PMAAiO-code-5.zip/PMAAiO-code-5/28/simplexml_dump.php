<?php
$theData = simplexml_load_file("books.xml");
echo "<pre>";
print_r($theData);
echo "</pre>";
?>