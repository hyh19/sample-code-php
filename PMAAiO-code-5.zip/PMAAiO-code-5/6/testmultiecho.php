<?php
$display_prices = true;
if ($display_prices) {
	echo "<table border=\"1\">\n";
	echo "<tr><td colspan=\"3\">";
	echo "today's prices in dollars";
	echo "</td></tr>";
	echo "<tr><td>\$14.00</td><td>\$32.00</td><td>\$71.00</td></tr>\n";
	echo "</table>";
}
?>
