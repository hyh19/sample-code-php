<?php
$mood = "sad";
if ($mood == "happy") {
	 echo "Hooray! I'm in a good mood!";
} else {
	 echo "I'm in a $mood mood.";
}
?>
