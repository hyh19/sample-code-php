<?php
$mood = "sad";
$text = ($mood == "happy") ? "I am in a good mood!" : "I am in a $mood mood.";
echo "$text";
?>
