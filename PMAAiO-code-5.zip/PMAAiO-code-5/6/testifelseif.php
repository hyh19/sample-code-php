<?php
$mood = "sad";
if ($mood == "happy") {
	echo "Hooray! I'm in a good mood!";
} elseif ($mood == "sad") {
	 echo "Awww. Don't be down!";
} else {
	echo "I'm neither happy nor sad, but $mood.";
}
?>
