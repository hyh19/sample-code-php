<?php
$mood = "happy";
if ($mood == "happy") {
	echo "Hooray! I'm in a good mood!";
}
?>
