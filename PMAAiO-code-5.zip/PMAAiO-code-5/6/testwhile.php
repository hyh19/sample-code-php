<?php
$counter = 1;
while ($counter <= 12) {
	echo $counter." times 2 is ".($counter * 2)."<br/>";
	$counter++;
}
?>
