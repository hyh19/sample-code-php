<?php
function test()
{
	 $testvariable = "this is a test variable";
}
echo "test variable: ".$testvariable."<br/>";
?>
