<?php
function bighello()
{
	 echo "<h1>HELLO!</h1>";
}
bighello();
?>
