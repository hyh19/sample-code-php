<?php
$num = -321;
$newnum = abs($num);
echo $newnum;
//prints "321"
?>
