<?php
$life = 42;
function meaningOfLife()
{
	echo "The meaning of life is ".$life;
}
meaningOfLife();
?>
