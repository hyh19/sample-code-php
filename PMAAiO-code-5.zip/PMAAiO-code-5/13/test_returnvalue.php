<?php
$addResult = include 'returnvalue.php';
echo "The include file returned ".$addResult;
?>
