<?php
include 'myinclude.php';
?>