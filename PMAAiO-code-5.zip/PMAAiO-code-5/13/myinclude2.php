<?php
echo "I have been included!!<br/>";
echo "But now I can add up...  4 + 4 = ".(4 + 4);
?>
