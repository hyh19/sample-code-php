<?php
$retval = ( 4 + 4 );
return $retval;
?>
This HTML will never be displayed because it comes after a return statement!
