<?php
$filename = "test.txt";
$fp = fopen($filename, "r") or die("Couldn't open $filename");
while (!feof($fp)) {
	$chunk = fread($fp, 8);
	echo $chunk."<br/>";
}
?>
