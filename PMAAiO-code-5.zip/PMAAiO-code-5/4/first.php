<?php
    echo "<h1>Hello Web!</h1>";
?>
